#include <iostream>

using namespace std;

class ArrayDouble
{
public:
	ArrayDouble()
	{
		arr = nullptr;
		SizeArr = 0;
		memoryArrSize = 0;
	}
	~ArrayDouble() // should clean up the storage 
	{
		delete[] arr;
	}
	ArrayDouble(const ArrayDouble & other) // copy ctor
	{
		if (SizeArr > other.SizeArr)
		{
			delete arr;
			SizeArr = other.SizeArr;
			arr = new double[SizeArr];
			memoryArrSize = SizeArr;
		}
		else
		{
			for (size_t i = 0; i < other.SizeArr; i++)
			{
				arr[i] = other.arr[i];
			}
			SizeArr = other.SizeArr;
		}
		
	}
	ArrayDouble &operator=(const ArrayDouble &other) // copy assignment
	{
		SizeArr = other.SizeArr;
		if (SizeArr > memoryArrSize)
		{
			double* newArr = new double[SizeArr];
			memoryArrSize = SizeArr;
			delete[] arr;
			arr = newArr;
		}
		for (size_t i = 0; i < SizeArr; i++)
		{
			arr[i] = other.arr[i];
		}
		return *this;
	}
	size_t Count() const // returns number of elements in array
	{
		return SizeArr;
	}
	void Push(double d) // adds d to the end of the array, resising the storage if necessary
	{
		int newArrSize = SizeArr;
		++newArrSize;
		if (newArrSize > memoryArrSize)
		{
			double* newArr = new double[newArrSize];
			for (size_t i = 0; i < SizeArr; i++)
			{
				newArr[i] = arr[i];
			}
			SizeArr+=1;
			memoryArrSize+=1;
			newArr[SizeArr - 1] = d;
			delete[] arr;
			arr = newArr;
		}
		else
		{
			arr[SizeArr] = d;
			SizeArr+=1;
		}
		std::cout << "Array Push: "<< d << std::endl;
	}
	double &operator[](size_t idx) // subscript operator overload to mutate the value at index idx
	{
		return *(arr + idx);
	}
	const double &operator[](size_t idx) const // read only subscript operator overload
	{
		return *(arr + idx);
	}
	bool IsEmpty() const // whether array has no elements
	{
		return SizeArr == 0 ? true : false;
	}
	void Clear() // removes all elements of the array, after that IsEmpty should return true
	{
		SizeArr = 0;
		std::cout << "Array Clear " << std::endl;
	}
	void PrintInfo()
	{
		std::cout << "SizeArr: " << SizeArr << std::endl;
		std::cout << "MemorySizeArr: " << memoryArrSize << std::endl;
		for (size_t i = 0; i < SizeArr; i++)
		{
			std::cout<<"elem "<<i<<": "<< arr[i]<<std::endl;
		}
		std::cout << std::endl;
	}

private:

	double *arr;
	size_t SizeArr;
	size_t memoryArrSize;
	
};


int main()
{
	ArrayDouble Array;
	Array.PrintInfo();
	Array.Push(5);
	Array.PrintInfo();
	Array.Push(7);
	Array.PrintInfo();
	Array.Push(24);
	Array.PrintInfo();
	Array.Clear();
	Array.PrintInfo();
	Array.IsEmpty();
	Array.PrintInfo();


	ArrayDouble Array2;
	Array2.PrintInfo();
	Array2.Push(9);
	Array2.PrintInfo();
	Array2.Push(15);
	Array2.PrintInfo();
	Array2.Push(34);
	Array2.Push(4);
	Array2.PrintInfo();

	Array = Array2;
	Array.PrintInfo();
}